package lambda.streamsempty.helperclasses;

public enum Status {
    ACTIVE,
    BLOCKED,
    REMOVED
}
